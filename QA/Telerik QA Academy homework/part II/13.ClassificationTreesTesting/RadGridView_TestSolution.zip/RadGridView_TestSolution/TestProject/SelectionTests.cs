﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Telerik.WebAii.Controls.Xaml;

namespace TestProject
{
    [TestClass]
    public class SelectionTests : GridViewBaseTest
    {
        [TestInitialize]
        public override void InitializeTest()
        {
            base.InitializeTest();
        }
        
        //HINTS
        //Sets the SelectionMode toSingle
        //this.SelectionModeCombo.SelectedIndex = 0; 
        //Sets the SelectionMode Multiple
        //this.SelectionModeCombo.SelectedIndex = 1; 
        //Sets the SelectionMode Extended 
        //this.SelectionModeCombo.SelectedIndex = 2; 

        //Sets the SelectionUnit to Cell
        //this.SelectionUnitCombo.SelectedIndex = 0;
        //Sets the SelectionUnit to FullRow
        //this.SelectionUnitCombo.SelectedIndex = 1; 

        //Sets the property CanUserSelect
        //this.CanUserSelectCheckBox.IsChecked = false;

        //There is an IList collection of Rows
        //Every row can be accessed by its index
        //Each row has an IList collection of Cells
        //Every cell can be accessed by its index

        [TestMethod]
        public void TestMethod1()
        {
            this.SelectionModeCombo.SelectedIndex = 0;
            this.SelectionUnitCombo.SelectedIndex = 1;
           
            GridViewRow row = this.gridView.Rows[1];
            row.User.Click();
            bool isSelected = row.IsSelected;
            Assert.IsTrue(isSelected);
        }
    }
}
