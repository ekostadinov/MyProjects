﻿namespace RadGridView
{
    /// <summary>
    /// A football position.
    /// </summary>
    public enum Position
    {
        GK,
        DF,
        MF,
        FW
    }
}
