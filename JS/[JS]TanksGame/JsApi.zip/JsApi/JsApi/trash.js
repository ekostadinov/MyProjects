﻿'use strict';

var startGame = (function () {
    var gameStart = new Date().getTime() / 1000;
    localStorage.setItem("start", gameStart);
   
    var trashCanHeight = 450;
    var trashCount = 10;
    var documentFragment = document.createDocumentFragment();

    localStorage.setItem("count", trashCount);

    for (var i = 0; i < trashCount; i++) {
        var trash = document.createElement('img');        
        trash.style.position = 'absolute';
        trash.style.top = getRandomPosition(trashCanHeight, screen.height - 250) + 'px';
        trash.style.left = getRandomPosition(0, screen.width - 250) + 'px';
        trash.setAttribute('id', i);
        trash.setAttribute('src', 'trash.png');
        trash.setAttribute('draggable', 'true');
        trash.setAttribute('ondragstart', 'handleDragStart(event)');
        trash.setAttribute('ondragend', 'handleDragEnd(event)');

        documentFragment.appendChild(trash);
    }
    document.body.appendChild(documentFragment);

    function getRandomPosition(start, end) {
        var random = Math.floor((Math.random() * (end - start) + start));
        return random;       
    }
});